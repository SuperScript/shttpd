#ifndef HTTPDATE_H
#define HTTPDATE_H

#include "stralloc.h"
#include "tai.h"

extern int httpdate(stralloc *,struct tai *);

#endif
