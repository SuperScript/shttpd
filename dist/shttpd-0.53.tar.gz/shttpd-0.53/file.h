#ifndef FILE_H
#define FILE_H

#include "tai.h"

extern int file_open(const char *,struct tai *,unsigned long *,int);

#endif
