#ifndef DROPROOT_H
#define DROPROOT_H

extern void droproot(const char *);

#endif
