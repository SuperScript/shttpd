#ifndef PATHDECODE_H
#define PATHDECODE_H

#include "stralloc.h"

extern void pathdecode(stralloc *);

#endif
