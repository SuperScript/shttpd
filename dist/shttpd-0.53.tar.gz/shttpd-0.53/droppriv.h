#ifndef DROPPRIV_H
#define DROPPRIV_H

extern void droppriv(char *);

#endif
