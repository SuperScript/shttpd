#include "auto_home.h"

void hier()
{
  h(auto_home,-1,-1,02755);

  d(auto_home,"bin",-1,-1,02755);

  c(auto_home,"bin","cgi-config",-1,-1,0755);
  c(auto_home,"bin","cgi-dispatch",-1,-1,0755);
  c(auto_home,"bin","cgi-httpd",-1,-1,0755);
  c(auto_home,"bin","cgi-success",-1,-1,0755);
  c(auto_home,"bin","cgiuser-config",-1,-1,0755);
  c(auto_home,"bin","cgiuser-httpd",-1,-1,0755);
  c(auto_home,"bin","constant-config",-1,-1,0755);
  c(auto_home,"bin","constant-httpd",-1,-1,0755);
  c(auto_home,"bin","echo-config",-1,-1,0755);
  c(auto_home,"bin","echo-httpd",-1,-1,0755);
  c(auto_home,"bin","redir-config",-1,-1,0755);
  c(auto_home,"bin","redir-httpd",-1,-1,0755);
  c(auto_home,"bin","redir-data",-1,-1,0755);
}
