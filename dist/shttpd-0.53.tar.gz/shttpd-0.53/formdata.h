#ifndef FORMDATA_H
#define FORMDATA_H

#include "stralloc.h"

typedef struct {
  char *name; /* 0 means all names */
  int *flag;
  stralloc *value;
} formdata_action;

typedef struct {
  stralloc inprogress;
  formdata_action *action;
} formdata;

#define FORMDATA { {0} }

extern int formdata_init();
extern int formdata_field();

#endif
