#ifndef FILETYPE_H
#define FILETYPE_H

#include "stralloc.h"

extern void filetype(char *fn,stralloc *contenttype);

#endif
