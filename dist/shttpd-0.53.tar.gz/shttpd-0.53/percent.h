#ifndef PERCENT_H
#define PERCENT_H

#include "stralloc.h"

extern void percent(stralloc *);

#endif
