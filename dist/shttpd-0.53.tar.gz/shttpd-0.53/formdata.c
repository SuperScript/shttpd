#include "formdata.h"
#include "percent.h"

int formdata_init(h,a)
formdata *h;
formdata_action *a;
{
  h->action = a;

  for(;;) {
    if (a->value) if (!stralloc_copys(a->value,"")) return 0;
    if (a->flag) *a->flag = 0;

    if (!a->name) break;
    ++a;
  }

  return stralloc_copys(&h->inprogress,"");
}

int formdata_field(h,sa)
formdata *h;
stralloc *sa;
{
  formdata_action *a;
  int pos;
  char ch;
  int i;
  int j;

  if (!sa->len) return 1;

  if (!stralloc_copys(&h->inprogress,"")) return 0;
  for (pos = 0;pos < sa->len;++pos) {
    ch = sa->s[pos];
    if (ch == '=') break;
    if (ch == '+') ch = ' ';
    if (!stralloc_append(&h->inprogress,&ch)) return 0;
  }
  percent(&h->inprogress);

  /* Character entity or encoded = in name?  You lose. */
  for (a = h->action;a->name;++a)
    if (!case_diffb(h->inprogress.s,h->inprogress.len,a->name))
      break;

  if (pos < sa->len)
    if (sa->s[pos] == '=')
      ++pos;

  if (!stralloc_copys(&h->inprogress,"")) return 0;
  for (;pos < sa->len;++pos) {
    ch = sa->s[pos];
    if (ch == '+') ch = ' ';
    if (!stralloc_append(&h->inprogress,&ch)) return 0;
  }
  percent(&h->inprogress);

  if (!stralloc_ready(a->value,h->inprogress.len)) return 0;

  if (a->flag)
    *a->flag = 1;

  if (a->value) {
    if (!stralloc_copy(a->value,&h->inprogress)) return 0;
  }

  return 1;
}
